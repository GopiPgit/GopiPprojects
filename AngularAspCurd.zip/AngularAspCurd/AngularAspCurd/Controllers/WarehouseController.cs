﻿using AngularAspCurd.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;

namespace AngularAspCurd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseController : ControllerBase
    {
        private readonly WarehouseDbContext _warehouseDbContext;

        public WarehouseController(WarehouseDbContext warehouseDbContext)
        {
            _warehouseDbContext = warehouseDbContext;
        }

        [HttpGet()]
        public async Task<IEnumerable<Warehouse>> GetWarehouses()
        {
            return await _warehouseDbContext.Warehouse.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<Warehouse> Getbyid(int id)
        {
         var response=  _warehouseDbContext.Warehouse.SingleOrDefault(x=>x.Id==id);
            return response;
        }
       
        [HttpPost()]
        public async Task<Warehouse> PostWarehouse(Warehouse objWarehouse)
        {
            _warehouseDbContext.Warehouse.Add(objWarehouse);
            await _warehouseDbContext.SaveChangesAsync();
            return objWarehouse;
        }

        [HttpPut("{id}")]
        public async Task<Warehouse> Updatewarehouse(Warehouse objWarehouse)
        {
            _warehouseDbContext.Entry(objWarehouse).State = EntityState.Modified;
            await _warehouseDbContext.SaveChangesAsync();
            return objWarehouse;
        }
        [HttpDelete("{id}")]
        public bool DeleteWarehouse(int id)
        {
            bool a = false;
            var warehouse = _warehouseDbContext.Warehouse.Find(id);
            if (warehouse != null)
            {
                a = true;
                _warehouseDbContext.Entry(warehouse).State = EntityState.Deleted;
                _warehouseDbContext.SaveChanges();
            }
            else
            {
                a = false;
            }
            return a;
        }
    }
}
