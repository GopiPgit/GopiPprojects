﻿using Microsoft.AspNetCore.Components.Forms;
using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;

namespace AngularAspCurd.Models
{
    public class Warehouse
    {
        [Key]
        public int Id { get; set; }
        public string sourceWareHouse { get; set; }
        public string destinationWareHouse { get; set; }
        public DateTime dateofshipment { get; set; }
        public DateTime dateofdelivery { get; set; }
        public int weight { get; set; }  
    }
}
