﻿using Microsoft.EntityFrameworkCore;

namespace AngularAspCurd.Models
{
    public class WarehouseDbContext : DbContext
    {
        public WarehouseDbContext(DbContextOptions<WarehouseDbContext> options) : base(options)
        {
        }
        public DbSet<Warehouse> Warehouse { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=.; Initial Catalog=house; User Id=sa; password=123123; TrustServerCertificate= True");
        }
    }
}
